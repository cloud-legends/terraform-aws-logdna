const Logger = require('logdna');
const zlib = require('zlib');

const MAX_LINE_LENGTH = parseInt(process.env.LOGDNA_MAX_LINE_LENGTH) || 32000;
const ENVIRONMENT = process.env.ENVIRONMENT || 'acceptance';
const API_KEY = process.env.LOGDNA_KEY;

const sanitizeMessage = (message) => {
    if (message.length > MAX_LINE_LENGTH) {
        return message.substring(0, MAX_LINE_LENGTH) + ' (truncated)';
    }
    return message;
};

const parseEvent = (event) => {
    return JSON.parse(zlib.unzipSync(Buffer.from(event.awslogs.data, 'base64')));
};

const sanitizeHostname = (hostname) =>
    hostname.replace(/\/\b[a-f\d-]{36}/, "").replace(/\//g, "-");

// Main Handler
exports.handler = (event, context, callback) => {
    const parsedEvents = parseEvent(event);
    const options = {
        hostname: sanitizeHostname(parsedEvents.logStream),
        app: parsedEvents.logGroup,
        env: ENVIRONMENT,
        meta: {
            owner: parsedEvents.owner,
            filters: parsedEvents.subscriptionFilters
        }
    };

    const logger = Logger.createLogger(API_KEY, options);

    parsedEvents.logEvents.forEach((event) => {
        const sanitizedMessage = sanitizeMessage(event.message);
        logger.log(sanitizedMessage);
    });
};
