import base64
import certifi
import gzip
import json
import logging
import os
import socket
import ssl
import time
from StringIO import StringIO

# Set defaults
key = os.environ['LOGDNA_KEY']
path = '/logs/ingest'
port = 443
url = 'logs.logdna.com'

# Runs when called by AWS Lambda
def lambda_handler(event, context):
    # Open the socket
    sock = create_socket()
    # Retrieve CloudWatch logs and convert into dictionary
    cw_data = str(event['awslogs']['data'])
    cw_logs = gzip.GzipFile(fileobj=StringIO(cw_data.decode('base64', 'strict'))).read()
    cw_log_lines = json.loads(cw_logs)
    # Check for app and host options
    app = 'CloudWatch'
    hostname = 'CloudWatch'
    if 'logGroup' in cw_log_lines:
        app = cw_log_lines['logGroup']
    if 'logStream' in cw_log_lines:
        hostname = cw_log_lines['logStream']
    # Loop through the log lines to create array of lines
    json_object = { "lines": [] }
    for cw_log_line in cw_log_lines['logEvents']:
        json_object["lines"].append({
            "line": cw_log_line['message'],
            "timestamp": cw_log_line['timestamp'],
            "file": app
            })
    # Send log lines to LogDNA then cleanly close the socket
    send_to_logdna(sock, json.dumps(json_object), app, hostname)
    sock.close()

def create_socket():
    s_ = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s = ssl.wrap_socket(
                sock = s_,
                keyfile = None,
                certfile = None,
                server_side = False,
                cert_reqs = ssl.CERT_REQUIRED,
                ssl_version = getattr(
                    ssl,
                    'PROTOCOL_TLSv1_2',
                    ssl.PROTOCOL_TLSv1
                ),
                ca_certs = certifi.where(),
                do_handshake_on_connect = True,
                suppress_ragged_eofs = True,
            )
    try:
        s.connect((url, port))
        return s
    except socket.error, exc:
        print "Caught exception socket.error : %s" % exc

def send_to_logdna(ld_socket, payload, app, hostname):
    headers = """\
POST {path}?hostname={hostname} HTTP/1.1\r
Authorization: Basic {token}\r
Content-Type: application/json; charset=UTF-8\r
Content-Length: {content_length}\r
Host: {host}\r
Connection: close\r
\r\n"""
    headers = headers.format(
        path = path,
        hostname = hostname,
        token = base64.encodestring(key+':').strip(),
        content_length = len(payload),
        host = url)
    ld_socket.sendall('%s%s' % (headers, payload))
